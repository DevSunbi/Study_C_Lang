#include <stdlib.h>
#include <unistd.h>

int main() {
    // 1. 작은 메모리 할당 (brk 사용 가능성 높음)
    char *small = malloc(1024); 
    free(small);

    // 2. 아주 큰 메모리 할당 (mmap 사용)
    char *large = malloc(1024 * 1024 * 5); 
    free(large);

    return 0;
}

