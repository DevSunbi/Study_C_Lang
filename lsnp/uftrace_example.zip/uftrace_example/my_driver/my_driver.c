#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/delay.h>
#include <linux/cdev.h>
#include <linux/device.h> // 자동 장치 파일 생성을 위해 추가된 헤더

#define DEVICE_NAME "my_ubuntu_dev"
#define CLASS_NAME  "my_ubuntu_class"

MODULE_LICENSE("GPL");

static dev_t dev_num;
static struct cdev my_cdev;
static struct class *my_class = NULL;   // 장치 클래스 구조체 포인터
static struct device *my_device = NULL; // 장치 구조체 포인터

// uftrace 프로파일링용 가상 체증 함수
static void kernel_calculation_loop(void) {
    int i;
    for (i = 0; i < 2; i++) {
        mdelay(10); // 10ms씩 지연시켜 uftrace 리포트에 잡히도록 함
    }
}

static ssize_t dev_write(struct file *file, const char __user *buffer, size_t len, loff_t *offset) {
    char k_buf;

    if (len == 0) return 0;
    if (copy_from_user(&k_buf, buffer, 1)) return -EFAULT;

    // 디버깅용 예외 처리: 'X' 데이터가 들어오면 비정상 동작 유도
    if (k_buf == 'X') {
        pr_err("my_driver: [BUG] 부적절한 데이터 감지!\n");
        return -EINVAL; 
    }

    // 커널 내부 연산 수행
    kernel_calculation_loop();

    return len;
}

static struct file_operations fops = {
    .owner = THIS_MODULE,
    .write = dev_write,
};

static int __init my_driver_init(void) {
    int ret;

    // 1. 주번호 동적 할당
    ret = alloc_chrdev_region(&dev_num, 0, 1, DEVICE_NAME);
    if (ret < 0) {
        pr_err("my_driver: 주번호 할당 실패\n");
        return ret;
    }

    // 2. cdev 구조체 초기화 및 등록
    cdev_init(&my_cdev, &fops);
    my_cdev.owner = THIS_MODULE;
    ret = cdev_add(&my_cdev, dev_num, 1);
    if (ret < 0) {
        unregister_chrdev_region(dev_num, 1);
        pr_err("my_driver: 디바이스 등록 실패\n");
        return ret;
    }

    // 3. /sys/class/ 아래에 장치 클래스 생성 (우분투 24.04 최신 표준 매개변수 구조)
    my_class = class_create(CLASS_NAME);
    if (IS_ERR(my_class)) {
        cdev_del(&my_cdev);
        unregister_chrdev_region(dev_num, 1);
        pr_err("my_driver: 클래스 생성 실패\n");
        return PTR_ERR(my_class);
    }

    // 4. /dev/my_ubuntu_dev 장치 파일 자동으로 생성하기
    my_device = device_create(my_class, NULL, dev_num, NULL, DEVICE_NAME);
    if (IS_ERR(my_device)) {
        class_destroy(my_class);
        cdev_del(&my_cdev);
        unregister_chrdev_region(dev_num, 1);
        pr_err("my_driver: 장치 파일 생성 실패\n");
        return PTR_ERR(my_device);
    }

    pr_info("my_driver: 로드 및 /dev/%s 자동 생성 완료\n", DEVICE_NAME);
    return 0;
}

static void __exit my_driver_exit(void) {
    // 생성한 역순으로 제거 (메모리 해제 및 장치 파일 삭제)
    device_destroy(my_class, dev_num);
    class_destroy(my_class);
    cdev_del(&my_cdev);
    unregister_chrdev_region(dev_num, 1);
    pr_info("my_driver: 언로드 완료\n");
}

module_init(my_driver_init);
module_exit(my_driver_exit);

