#include <stdio.h>
#include <unistd.h>

int main() {
    printf("3초 동안 멈춥니다...\n");
    sleep(3);
    printf("종료합니다.\n");
    return 0;
}

