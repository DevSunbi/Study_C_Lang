#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

void send_data_to_driver(int fd, const char *msg, int size) {
    printf("[App] 드라이버에 '%c' 데이터를 전송합니다.\n", msg[0]);
    if (write(fd, msg, size) < 0) {
        perror("[App] write 연산 실패");
    }
}

int main(void) {
    int fd = open("/dev/my_ubuntu_dev", O_WRONLY);
    if (fd < 0) {
        perror("디바이스 노드 오픈 실패");
        return 1;
    }

    // 1. 정상 전송 (내부에서 20ms 지연 발생)
    send_data_to_driver(fd, "A", 1);

    // 2. 에러 유도 데이터 전송 (내부에서 에러 반환)
    send_data_to_driver(fd, "X", 1);

    close(fd);
    return 0;
}

