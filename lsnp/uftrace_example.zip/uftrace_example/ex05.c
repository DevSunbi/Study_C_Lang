#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

int main() {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return 1;

    struct sockaddr_in serv_addr;
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(80); // HTTP 포트
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1"); // 로컬 주소

    // 실제 연결은 실패하더라도 socket과 connect 호출은 utrace에 찍힙니다.
    connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
    close(sock);
    return 0;
}

