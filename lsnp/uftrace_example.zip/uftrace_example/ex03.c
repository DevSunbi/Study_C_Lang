#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    if (pid == 0) {
        // 자식 프로세스: ls 명령어 실행
        char *args[] = {"/bin/ls", NULL};
        execve(args[0], args, NULL);
    } else if (pid > 0) {
        // 부모 프로세스: 자식이 끝날 때까지 대기
        wait(NULL);
    }
    return 0;
}

